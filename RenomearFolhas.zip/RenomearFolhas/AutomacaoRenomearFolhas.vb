﻿Imports System.Runtime.InteropServices
Imports Inventor

<ComVisible(True)>
<Guid("c869d189-7f29-45fc-bfd7-923db33f2d55")>
Public Interface IAutomacaoRenomearFolhas
    Sub RenomearFolhas()
End Interface

<ComVisible(True)>
<Guid("5578dd13-e376-4275-a61f-21c1e95f0adc")>
<ClassInterface(ClassInterfaceType.None)>
Public Class AutomacaoRenomearFolhas
    Implements IAutomacaoRenomearFolhas

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub RenomearFolhas() Implements IAutomacaoRenomearFolhas.RenomearFolhas
        ' Chama o gestor responsável por carregar e executar a regra iLogic incorporada
        Dim gestor As New RenomearDeFolhas(_app)
        gestor.ExecutarRenomear()
    End Sub
End Class
