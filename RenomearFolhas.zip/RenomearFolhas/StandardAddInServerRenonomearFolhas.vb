﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor


<ComVisible(True)>
<Guid("143b2d81-4014-4223-b094-41e426bfba58")>
Public Class StandardAddInServerRenonomearFolhas
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoObj As AutomacaoRenomearFolhas
    Private meuBotao As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoObj
        End Get
    End Property

    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoObj = New AutomacaoRenomearFolhas(_inventorApp)

        If Not firstTime Then Exit Sub

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            Dim smallPicture As IPictureDisp = Nothing
            Dim largePicture As IPictureDisp = Nothing

            Dim recursoIconePequeno As String = "RenomearFolhas.16x16.ico"
            Dim recursoIconeGrande As String = "RenomearFolhas.32x32.ico"

            smallPicture = CarregarIconeEmb(assembly, recursoIconePequeno)
            largePicture = CarregarIconeEmb(assembly, recursoIconeGrande)

            ' Criação do botão (se não existir)
            Try
                meuBotao = DirectCast(controlDefs.Item("MyCompany_RenomearFolhas"), ButtonDefinition)
            Catch
                meuBotao = controlDefs.AddButtonDefinition(
                    "Renomear" & vbCrLf & "Folhas",
                    "MyCompany_RenomearFolhas",
                    CommandTypesEnum.kShapeEditCmdType,
                    "{0d342630-a2ca-4c49-8c7a-f85294783a64}",
                    "Executa regra iLogic de gestão de folhas",
                    "Gerenciar" & vbCrLf & "Folhas",
                    smallPicture,
                    largePicture)
            End Try

            AddHandler meuBotao.OnExecute, AddressOf BotaoRenomearFolhas_OnExecute

            ' Adiciona o botão à aba Tools do ambiente de desenho
            Dim ribbon As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Drawing")
            Dim tab As RibbonTab = ribbon.RibbonTabs("id_TabTools")

            Dim painel As RibbonPanel
            Try
                painel = tab.RibbonPanels.Item("PainelRenomearFolhas")
            Catch
                painel = tab.RibbonPanels.Add("Renomeação Folhas", "PainelRenomeaçãoFolhas", "MyCompany.PanelRenomearGUID")
            End Try

            Dim botaoExiste As Boolean = painel.CommandControls.Cast(Of CommandControl)().
                Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_RenomearFolhas")

            If Not botaoExiste Then
                painel.CommandControls.AddButton(meuBotao, True)
            End If

        Catch
            ' Silencioso: erros suprimidos
        End Try
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoObj = Nothing
        meuBotao = Nothing
    End Sub

    Public Sub ExecuteCommand(ByVal commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Não utilizado
    End Sub

    Private Sub BotaoRenomearFolhas_OnExecute(ByVal Context As NameValueMap)
        Try
            _automacaoObj?.RenomearFolhas()
        Catch
            ' Silencioso: exceção suprimida
        End Try
    End Sub

    ' Converte recurso .ico embutido em IPictureDisp
    Private Function CarregarIconeEmb(assembly As Assembly, nomeRecurso As String) As IPictureDisp
        Try
            Using stream As Stream = assembly.GetManifestResourceStream(nomeRecurso)
                If stream IsNot Nothing Then
                    Return IconToIPictureDisp(New Icon(stream))
                End If
            End Using
        Catch
            ' Silencioso
        End Try
        Return Nothing
    End Function

    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub

        Public Shared Function ImageToPictureDisp(image As System.Drawing.Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class

End Class
