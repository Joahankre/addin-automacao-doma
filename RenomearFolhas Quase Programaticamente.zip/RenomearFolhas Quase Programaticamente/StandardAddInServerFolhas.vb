﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor


<ComVisible(True)>
<Guid("e47b1465-fc28-4ea3-ba6a-b89838285392")>
Public Class StandardAddInServerFolhas
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoFolhas As AutomacaoFolhasAddIn
    Private botaoRenomear As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoFolhas
        End Get
    End Property

    Public Sub Activate(addInSiteObject As ApplicationAddInSite, firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoFolhas = New AutomacaoFolhasAddIn(_inventorApp)

        If firstTime Then
            Try
                Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
                Dim assembly As Assembly = Assembly.GetExecutingAssembly()

                ' Caminhos dos ícones
                Dim recursoIconePequeno As String = "RenomearFolhas.16x16.ico"
                Dim recursoIconeGrande As String = "RenomearFolhas.32x32.ico"

                ' Carrega ícones usando a função corrigida
                Dim smallPicture As IPictureDisp = LoadIcon(assembly, recursoIconePequeno)
                Dim largePicture As IPictureDisp = LoadIcon(assembly, recursoIconeGrande)

                ' Cria ou recupera botão
                Try
                    botaoRenomear = DirectCast(controlDefs.Item("MyCompany_RenomearFolhas"), ButtonDefinition)
                Catch
                    botaoRenomear = controlDefs.AddButtonDefinition(
                        "Renomear" & vbLf & "Folhas",
                        "MyCompany_RenomearFolhas",
                        CommandTypesEnum.kEditMaskCmdType,
                        Me.GetType().GUID.ToString("B"),
                        "Renomeia folhas do desenho com base em propriedades do modelo",
                        "Renomear" & vbLf & "Folhas",
                        smallPicture,
                        largePicture)
                End Try

                ' Evento do botão
                AddHandler botaoRenomear.OnExecute, AddressOf BotaoRenomear_OnExecute

                ' Ribbon Drawing > Tab id_TabTools
                Dim ribbon As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Drawing")
                Dim tab As RibbonTab = ribbon.RibbonTabs("id_TabTools")

                ' Painel
                Dim painel As RibbonPanel
                Try
                    painel = tab.RibbonPanels.Item("PainelRenomearFolhas")
                Catch
                    painel = tab.RibbonPanels.Add("Folhas", "PainelRenomearFolhas", Me.GetType().GUID.ToString("B"))
                End Try

                ' Adiciona botão se não existir
                Dim botaoExiste As Boolean = painel.CommandControls.Cast(Of CommandControl)().Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_RenomearFolhas")
                If Not botaoExiste Then painel.CommandControls.AddButton(botaoRenomear, True)

            Catch ex As Exception
                MessageBox.Show("Erro ao criar botão de renomeação: " & ex.Message, "Erro")
            End Try
        End If
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoFolhas = Nothing
    End Sub

    Public Sub ExecuteCommand(commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Não utilizado
    End Sub

    Private Sub BotaoRenomear_OnExecute(Context As NameValueMap)
        _automacaoFolhas.Executar()
    End Sub

    ' ================= Função para carregar ícones =================
    Private Function LoadIcon(assembly As Assembly, resourceName As String) As IPictureDisp
        Dim pic As IPictureDisp = Nothing
        Using stream As Stream = assembly.GetManifestResourceStream(resourceName)
            If stream IsNot Nothing Then
                pic = IconToIPictureDisp(New Icon(stream))
            End If
        End Using
        Return pic
    End Function

    ' Converte System.Drawing.Icon para stdole.IPictureDisp usando AxHost derivado
    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Dim bmp As Bitmap = icon.ToBitmap()
        Return AxHostConverter.ImageToPictureDisp(bmp)
    End Function

    ' Classe auxiliar para converter Image em IPictureDisp
    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub

        Public Shared Function ImageToPictureDisp(image As Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class

End Class
