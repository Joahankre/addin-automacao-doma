﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

<ComVisible(True)>
Public Class AutomacaoFolhasAddIn
    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Executar()
        ' Aqui chamamos o Add-In principal que você enviou
        Dim addin As New RenomearFolhasAddIn(_app)
        addin.Executar()
    End Sub
End Class
