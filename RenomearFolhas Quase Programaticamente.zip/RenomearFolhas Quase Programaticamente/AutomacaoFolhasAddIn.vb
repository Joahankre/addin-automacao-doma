﻿Imports Inventor
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.Text
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text.RegularExpressions

<ComVisible(True)>
Public Class RenomearFolhasAddIn

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub Executar()
        Try
            Dim dwgDoc As DrawingDocument = TryCast(_app.ActiveDocument, DrawingDocument)
            If dwgDoc Is Nothing Then
                MessageBox.Show("O documento ativo não é um desenho (.idw ou .dwg).", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Dim DebugMode As Boolean = True ' Ative para depuração

            ' Coleta nomes de todas as folhas
            Dim allSheetNames As New List(Of String)
            For Each sht As Sheet In dwgDoc.Sheets
                allSheetNames.Add(sht.Name)
            Next

            ' Seleção de folhas
            Dim selectedSheets As IEnumerable(Of Object) = MultiSelectListBoxWithPrefixFilter(
                "Selecione as folhas para renomear:", allSheetNames, Nothing, "Renomear Folhas", "Folhas do desenho"
            )
            If selectedSheets Is Nothing OrElse selectedSheets.Count = 0 Then Exit Sub

            If selectedSheets.Contains("**[Selecionar Todas]**") Then
                selectedSheets = dwgDoc.Sheets.Cast(Of Sheet).Select(Function(s) s.Name).ToList()
            End If

            ' Coleta BOM do desenho (se houver)
            Dim BOMRows As BOMRowsEnumerator = GetBOMRows(dwgDoc)

            Dim renomeadas As New StringBuilder
            Dim novosNomes As New List(Of String)

            ' Loop pelas folhas selecionadas
            For Each dwgSheet As Sheet In dwgDoc.Sheets
                If Not selectedSheets.Contains(dwgSheet.Name) Then Continue For
                If dwgSheet.DrawingViews.Count = 0 Then Continue For

                Dim refDoc As Document = Nothing

                ' Procura a primeira vista com documento válido
                For Each view As DrawingView In dwgSheet.DrawingViews
                    Try
                        Dim desc As Object = Nothing
                        Try
                            desc = view.ReferencedDocumentDescriptor
                        Catch
                        End Try

                        If desc IsNot Nothing Then
                            Try
                                refDoc = desc.ReferencedDocument
                            Catch
                            End Try
                        End If
                    Catch
                    End Try
                    If refDoc IsNot Nothing Then Exit For
                Next

                If refDoc Is Nothing Then
                    If DebugMode Then MessageBox.Show("❌ Nenhuma vista válida encontrada na folha " & dwgSheet.Name)
                    Continue For
                End If

                ' Propriedades do documento
                Dim docFName As String = System.IO.Path.GetFileName(refDoc.FullFileName)
                Dim descricao As String = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Description"))
                Dim codPeca As String = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Número da peça"))
                If codPeca = "X" Then codPeca = SanitizeText(SafeGetPropertyValue(refDoc, "Design Tracking Properties", "Part Number"))

                Dim categoryRaw As String = ""
                Try
                    categoryRaw = refDoc.PropertySets.Item("SummaryInformation").Item("Category").Value
                Catch
                End Try

                Dim categoria As String = "N-A"
                If InStr(categoryRaw, " - ") > 0 Then
                    categoria = Trim(Split(categoryRaw, "-")(0))
                ElseIf Trim(categoryRaw) <> "" Then
                    categoria = Trim(categoryRaw)
                End If

                ' Item BOM
                Dim itemBOM As String = ""
                If BOMRows IsNot Nothing Then itemBOM = SearchBOMByPartNumber(BOMRows, codPeca)
                If itemBOM = "" Then itemBOM = "N-A"

                If DebugMode Then
                    MessageBox.Show(
                        "🏷 Folha: " & dwgSheet.Name & vbCrLf &
                        "Arquivo: " & docFName & vbCrLf &
                        "Descrição: " & descricao & vbCrLf &
                        "Código: " & codPeca & vbCrLf &
                        "Categoria: " & categoria & vbCrLf &
                        "Item BOM: " & itemBOM
                    )
                End If

                If categoria = "N-A" Or descricao = "X" Or codPeca = "X" Then Continue For

                ' Monta novo nome
                Dim parts As New List(Of String)
                If categoria <> "N-A" AndAlso categoria <> "" Then parts.Add(categoria)
                If itemBOM <> "N-A" AndAlso itemBOM <> "" Then parts.Add(itemBOM)
                If codPeca <> "X" AndAlso codPeca <> "" Then parts.Add(codPeca)

                Dim novoNome As String = String.Join(" - ", parts)

                If IsAssemblyDocument(refDoc.FullFileName) AndAlso Not novoNome.ToUpper().EndsWith("ASS'Y") Then
                    novoNome &= " ASS'Y"
                End If

                ' Evita nomes duplicados
                If novosNomes.Contains(novoNome) Then
                    novoNome &= " (" & Now.Ticks.ToString().Substring(10) & ")"
                End If

                novosNomes.Add(novoNome)
                renomeadas.AppendLine("• " & dwgSheet.Name & " → " & novoNome)

                ' Aplica renomeação
                dwgSheet.Name = novoNome
            Next

            ' Atualiza e salva documento
            dwgDoc.Update()
            dwgDoc.Save2(True)

            ' Mostra resultado
            ShowFormattedResults(renomeadas.ToString())

        Catch ex As Exception
            MessageBox.Show("Erro ao executar renomeação: " & ex.Message)
        End Try
    End Sub

    ' ========================= FUNÇÕES AUXILIARES =========================

    Private Function SafeGetPropertyValue(doc As Document, propSetName As String, propName As String) As String
        Try
            Return doc.PropertySets.Item(propSetName).Item(propName).Value
        Catch
            Return "X"
        End Try
    End Function

    Private Function SanitizeText(inputText As String) As String
        If inputText Is Nothing Then Return ""
        Dim invalidChars As String = "<>:,""\/|?*{}[]()'´`"
        For Each c As Char In invalidChars
            inputText = inputText.Replace(c, "_")
        Next
        inputText = Regex.Replace(inputText, "\s+", " ")
        Return inputText.Trim()
    End Function

    Private Function GetBOMRows(dwgDoc As DrawingDocument) As BOMRowsEnumerator
        Try
            Dim firstSheet As Sheet = dwgDoc.Sheets.Item(1)
            Dim refDoc As Document = Nothing
            ' Procura assembly nas views
            For Each view As DrawingView In firstSheet.DrawingViews
                Try
                    Dim desc As Object = Nothing
                    Try
                        desc = view.ReferencedDocumentDescriptor
                    Catch
                    End Try

                    If desc IsNot Nothing Then
                        Dim doc As Document = Nothing
                        Try
                            doc = desc.ReferencedDocument
                        Catch
                        End Try

                        If doc IsNot Nothing AndAlso TypeOf doc Is AssemblyDocument Then
                            refDoc = doc
                            Exit For
                        End If
                    End If
                Catch
                End Try
            Next

            If refDoc Is Nothing Then Return Nothing

            Dim asmDoc As AssemblyDocument = CType(refDoc, AssemblyDocument)
            With asmDoc.ComponentDefinition.BOM
                .StructuredViewEnabled = True
                .StructuredViewFirstLevelOnly = False
                For Each view As BOMView In .BOMViews
                    If view.ViewType = BOMViewTypeEnum.kStructuredBOMViewType Then
                        Return view.BOMRows
                    End If
                Next
            End With
        Catch
        End Try
        Return Nothing
    End Function

    Private Function SearchBOMByPartNumber(rows As BOMRowsEnumerator, targetPartNumber As String) As String
        Dim targetSanitized As String = SanitizeText(targetPartNumber).Trim().ToUpper()
        For Each Row As BOMRow In rows
            Try
                If Row.ComponentDefinitions.Count = 0 Then Continue For
                Dim def As ComponentDefinition = Row.ComponentDefinitions.Item(1)
                Dim doc As Document = def.Document
                Dim rowPartNumber As String = ""
                Try
                    rowPartNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value
                Catch
                    rowPartNumber = ""
                End Try
                Dim rowSanitized As String = SanitizeText(rowPartNumber).Trim().ToUpper()
                If rowSanitized = targetSanitized Then Return Row.ItemNumber
                If Row.ChildRows IsNot Nothing Then
                    Dim childResult As String = SearchBOMByPartNumber(Row.ChildRows, targetPartNumber)
                    If childResult <> "" Then Return childResult
                End If
            Catch
            End Try
        Next
        Return ""
    End Function

    Private Function IsAssemblyDocument(filePath As String) As Boolean
        Return UCase(System.IO.Path.GetExtension(filePath)) = ".IAM"
    End Function

    Private Sub ShowFormattedResults(message As String)
        Dim form As New Form With {.Text = "RESULTADO DA RENOMEAÇÃO", .Width = 1500, .Height = 800}
        Dim richText As New RichTextBox With {.Dock = DockStyle.Fill, .ReadOnly = True}
        richText.AppendText("RENOMEAÇÃO CONCLUÍDA:" & vbCrLf & vbCrLf)
        richText.AppendText(message)
        form.Controls.Add(richText)
        form.ShowDialog()
    End Sub

    ' ==================== SELEÇÃO MÚLTIPLA ====================
    Private Function MultiSelectListBoxWithPrefixFilter(Optional Instructions As String = "", Optional Items As IEnumerable = Nothing, Optional DefaultValue As Object = Nothing, Optional Title As String = "", Optional ListName As String = "") As IEnumerable(Of Object)
        Dim form As New Form With {.Text = If(Title <> "", Title, "Seleção de Itens"), .Width = 600, .Height = 700, .StartPosition = FormStartPosition.CenterScreen}
        Dim label As New Label With {.Text = Instructions, .Dock = DockStyle.Top, .Height = 20}
        form.Controls.Add(label)
        Dim clb As New CheckedListBox With {.CheckOnClick = True, .Dock = DockStyle.Top, .Height = 450}
        form.Controls.Add(clb)
        Dim prefixTextBox As New System.Windows.Forms.TextBox With {.Dock = DockStyle.Top, .Height = 25}
        form.Controls.Add(prefixTextBox)
        Dim btnFilter As New Button With {.Text = "Aplicar Filtro", .Dock = DockStyle.Top, .Height = 30}
        AddHandler btnFilter.Click, Sub()
                                        Dim prefix As String = prefixTextBox.Text.Trim()
                                        clb.Items.Clear()
                                        For Each item In Items
                                            If prefix = "" OrElse item.ToString().StartsWith(prefix, StringComparison.CurrentCultureIgnoreCase) Then
                                                clb.Items.Add(item, False)
                                            End If
                                        Next
                                    End Sub
        form.Controls.Add(btnFilter)
        Dim btnMarcarTodas As New Button With {.Text = "Marcar Todas as Folhas", .Dock = DockStyle.Top, .Height = 30}
        AddHandler btnMarcarTodas.Click, Sub()
                                             For i As Integer = 0 To clb.Items.Count - 1
                                                 clb.SetItemChecked(i, True)
                                             Next
                                         End Sub
        form.Controls.Add(btnMarcarTodas)
        Dim btnDesmarcarTodas As New Button With {.Text = "Desmarcar Todas as Folhas", .Dock = DockStyle.Top, .Height = 30}
        AddHandler btnDesmarcarTodas.Click, Sub()
                                                For i As Integer = 0 To clb.Items.Count - 1
                                                    clb.SetItemChecked(i, False)
                                                Next
                                            End Sub
        form.Controls.Add(btnDesmarcarTodas)
        Dim okButton As New Button With {.Text = "Confirmar Seleção", .Dock = DockStyle.Bottom, .Height = 30}
        AddHandler okButton.Click, Sub() form.DialogResult = DialogResult.OK
        form.Controls.Add(okButton)
        For Each item In Items
            clb.Items.Add(item, False)
        Next
        If form.ShowDialog() = DialogResult.OK Then
            Dim selectedItems As New List(Of Object)
            For Each item In clb.CheckedItems
                selectedItems.Add(item)
            Next
            Return selectedItems
        Else
            Return Nothing
        End If
    End Function

End Class
