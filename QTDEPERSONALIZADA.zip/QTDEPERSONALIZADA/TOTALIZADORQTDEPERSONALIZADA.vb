﻿Imports System.Windows.Forms
Imports Inventor
Imports System.Collections.Generic

Public Class MultiplicadorQTDE

    Private _inventorApp As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _inventorApp = app
    End Sub

    ' ===============================
    ' Método principal
    ' ===============================
    Public Sub Executar()
        Try
            Dim oDoc As Document = _inventorApp.ActiveDocument
            If oDoc.DocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
                MessageBox.Show("Esta regra só pode ser executada em um arquivo de montagem.", "Erro")
                Return
            End If

            Dim input As String = InputBox("Digite a quantidade de vezes que este projeto será produzido:", "Multiplicador de Projeto", "1")
            If Not IsNumeric(input) Then
                MessageBox.Show("Valor inválido. Use apenas números.", "Erro")
                Return
            End If

            Dim multiplicador As Integer = CInt(input)
            If multiplicador < 1 Then
                MessageBox.Show("O multiplicador deve ser maior ou igual a 1.", "Erro")
                Return
            End If

            Dim oBOMQTY As String = "QTDE PERSONALIZADA"

            ExecutarMultiplicadorSimples(oDoc, oBOMQTY, multiplicador)
            ExecutarMultiplicadorFrame(oDoc, oBOMQTY, multiplicador)

            MessageBox.Show("Processo concluído com sucesso!" & vbCrLf & "Multiplicador aplicado: " & multiplicador, "Concluído")

        Catch ex As Exception
            MessageBox.Show("Erro ao executar multiplicador: " & ex.Message)
        End Try
    End Sub

    ' ===============================
    ' Multiplicador simples
    ' ===============================
    Private Sub ExecutarMultiplicadorSimples(oDoc As Document, oBOMQTY As String, multiplicador As Integer)
        Try
            Dim asmDoc As AssemblyDocument = CType(oDoc, AssemblyDocument)
            Dim occurrences As ComponentOccurrencesEnumerator = asmDoc.ComponentDefinition.Occurrences

            ' ProgressBar
            Dim oProgressBar As Inventor.ProgressBar = _inventorApp.CreateProgressBar(False, occurrences.Count, "Atualizando propriedades...")
            oProgressBar.Message = "Iniciando atualização..."
            oProgressBar.UpdateProgress()

            For i As Integer = 1 To occurrences.Count
                Dim occ As ComponentOccurrence = Nothing
                Try
                    occ = occurrences.Item(i)
                Catch
                    Continue For
                End Try

                If occ Is Nothing Then Continue For

                Dim doc As Document = Nothing
                Try
                    doc = occ.Definition.Document
                Catch
                    Continue For
                End Try

                If doc Is Nothing Then Continue For

                ' Atualiza propriedade personalizada
                Try
                    Dim propSet As PropertySet = doc.PropertySets.Item("Inventor User Defined Properties")
                    Dim valorAtual As Integer = 1
                    Try
                        valorAtual = CInt(propSet.Item(oBOMQTY).Value)
                    Catch
                    End Try
                    Try
                        propSet.Item(oBOMQTY).Value = valorAtual * multiplicador
                    Catch
                        propSet.Add(valorAtual * multiplicador, oBOMQTY)
                    End Try
                Catch
                End Try

                ' Atualiza ProgressBar
                oProgressBar.Message = $"Atualizando simples: {i} de {occurrences.Count}"
                oProgressBar.UpdateProgress()
            Next

            ' Atualiza a própria montagem
            Try
                Dim propSetAsm As PropertySet = oDoc.PropertySets.Item("Inventor User Defined Properties")
                Dim valorAsm As Integer = 1
                Try
                    valorAsm = CInt(propSetAsm.Item(oBOMQTY).Value)
                Catch
                End Try
                Try
                    propSetAsm.Item(oBOMQTY).Value = valorAsm * multiplicador
                Catch
                    propSetAsm.Add(valorAsm * multiplicador, oBOMQTY)
                End Try
            Catch
            End Try

            oProgressBar.Close()

        Catch ex As Exception
            MessageBox.Show("Erro no multiplicador simples: " & ex.Message)
        End Try
    End Sub

    ' ===============================
    ' Multiplicador frame
    ' ===============================
    Private Sub ExecutarMultiplicadorFrame(oDoc As Document, oBOMQTY As String, multiplicador As Integer)
        Try
            Dim asmDoc As AssemblyDocument = CType(oDoc, AssemblyDocument)
            Dim bom As BOM = asmDoc.ComponentDefinition.BOM
            bom.StructuredViewEnabled = True

            Dim modelDataView As BOMView = Nothing
            For i As Integer = 1 To bom.BOMViews.Count
                Dim view As BOMView = bom.BOMViews.Item(i)
                If view.ViewType = BOMViewTypeEnum.kModelDataBOMViewType Then
                    modelDataView = view
                    Exit For
                End If
            Next

            If modelDataView Is Nothing Then
                MessageBox.Show("BOM View do tipo Model Data não encontrada.", "Erro")
                Return
            End If

            ' Coleta todas as montagens Frame
            Dim frameRows As New List(Of BOMRow)
            For i As Integer = 1 To modelDataView.BOMRows.Count
                ColetarMontagensFrameRecursivo(modelDataView.BOMRows.Item(i), frameRows)
            Next

            If frameRows.Count = 0 Then Return

            ' ProgressBar
            Dim oProgressBar As Inventor.ProgressBar = _inventorApp.CreateProgressBar(False, frameRows.Count, "Atualizando montagens Frame...")
            oProgressBar.Message = "Iniciando atualização..."
            oProgressBar.UpdateProgress()

            ' Contagem de partes
            Dim partCount As New Dictionary(Of String, Integer)(StringComparer.InvariantCultureIgnoreCase)
            For Each row As BOMRow In frameRows
                ContarPartesPorMassa(row, partCount)
            Next

            ' Aplica multiplicador
            Dim partCountMultiplicado As New Dictionary(Of String, Integer)(StringComparer.InvariantCultureIgnoreCase)
            For Each kvp In partCount
                partCountMultiplicado.Add(kvp.Key, kvp.Value * multiplicador)
            Next

            ' Atualiza propriedades
            AtualizarPropriedadesPersonalizadas(oBOMQTY, partCountMultiplicado, oProgressBar)

            oProgressBar.Close()

        Catch ex As Exception
            MessageBox.Show("Erro no multiplicador Frame: " & ex.Message)
        End Try
    End Sub

    ' ===============================
    ' Funções auxiliares
    ' ===============================
    Private Sub ColetarMontagensFrameRecursivo(row As BOMRow, lista As List(Of BOMRow))
        Try
            If row.ComponentDefinitions.Count > 0 Then
                Dim compDef As ComponentDefinition = row.ComponentDefinitions.Item(1)
                Dim doc As Document = compDef.Document
                Dim partNumber As String = "(sem PN)"
                Try
                    partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                Catch
                End Try

                If partNumber.StartsWith("Frame", StringComparison.InvariantCultureIgnoreCase) Then
                    lista.Add(row)
                End If

                If Not partNumber.StartsWith("Skeleton", StringComparison.InvariantCultureIgnoreCase) Then
                    If row.ChildRows IsNot Nothing Then
                        For i As Integer = 1 To row.ChildRows.Count
                            ColetarMontagensFrameRecursivo(row.ChildRows.Item(i), lista)
                        Next
                    End If
                End If
            End If
        Catch
        End Try
    End Sub

    Private Sub ContarPartesPorMassa(row As BOMRow, dict As Dictionary(Of String, Integer))
        Try
            If row.ComponentDefinitions.Count > 0 Then
                Dim compDef As ComponentDefinition = row.ComponentDefinitions.Item(1)
                Dim doc As Document = compDef.Document
                Dim partNumber As String = "(sem PN)"
                Dim massa As Double = 0.0

                Try
                    partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                Catch
                End Try

                Try
                    massa = doc.ComponentDefinition.MassProperties.Mass
                Catch
                End Try

                Dim key As String = partNumber & "|" & Math.Round(massa, 5).ToString()

                If dict.ContainsKey(key) Then
                    dict(key) += 1
                Else
                    dict.Add(key, 1)
                End If
            End If

            If row.ChildRows IsNot Nothing Then
                For i As Integer = 1 To row.ChildRows.Count
                    ContarPartesPorMassa(row.ChildRows.Item(i), dict)
                Next
            End If
        Catch
        End Try
    End Sub

    Private Sub AtualizarPropriedadesPersonalizadas(oBOMQTY As String, dict As Dictionary(Of String, Integer), oProgressBar As Inventor.ProgressBar)
        Dim totalSteps As Integer = dict.Count
        Dim stepCount As Integer = 0

        For Each kvp In dict
            Dim keyParts() As String = kvp.Key.Split("|"c)
            Dim partNumber As String = keyParts(0)
            Dim massaKey As Double = CDbl(keyParts(1))

            For i As Integer = 1 To _inventorApp.Documents.Count
                Try
                    Dim doc As Document = _inventorApp.Documents.Item(i)
                    Dim pn As String = "(sem PN)"
                    Try
                        pn = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                    Catch
                    End Try

                    If pn.Equals(partNumber, StringComparison.InvariantCultureIgnoreCase) Then
                        Dim massaDoc As Double = 0.0
                        Try
                            massaDoc = doc.ComponentDefinition.MassProperties.Mass
                        Catch
                        End Try

                        If Math.Abs(massaDoc - massaKey) < 0.0001 Then
                            ' Atualiza propriedade
                            Try
                                Dim propSet As PropertySet = doc.PropertySets.Item("Inventor User Defined Properties")
                                Try
                                    propSet.Item(oBOMQTY).Value = kvp.Value
                                Catch
                                    propSet.Add(kvp.Value, oBOMQTY)
                                End Try
                            Catch
                            End Try
                        End If
                    End If
                Catch
                End Try
            Next

            stepCount += 1
            oProgressBar.Message = $"Atualizando frame: {stepCount} de {totalSteps}"
            oProgressBar.UpdateProgress()
        Next
    End Sub

End Class
