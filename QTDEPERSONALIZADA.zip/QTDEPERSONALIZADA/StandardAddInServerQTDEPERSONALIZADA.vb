﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor


<ComVisible(True)>
<Guid("93b327ef-3e54-4f0f-9f8b-e9aace54b96a")>
Public Class StandardAddInServerQTDEPERSONALIZADA
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoQTDE As AutomacaoQTDEPERSONALIZADA
    Private botaoSincronizarQTDE As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoQTDE
        End Get
    End Property

    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoQTDE = New AutomacaoQTDEPERSONALIZADA(_inventorApp)

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            ' === CARREGAR ÍCONES EMBUTIDOS ===
            Dim smallIcon As IPictureDisp = Nothing
            Dim largeIcon As IPictureDisp = Nothing

            Try
                Dim resources = assembly.GetManifestResourceNames()

                ' Nome dos recursos (ajuste se usar subpasta)
                Dim resource16 = resources.FirstOrDefault(Function(r) r.EndsWith("16x16.ico"))
                Dim resource32 = resources.FirstOrDefault(Function(r) r.EndsWith("32x32.ico"))

                If resource16 IsNot Nothing Then
                    Using stream16 As Stream = assembly.GetManifestResourceStream(resource16)
                        smallIcon = IconToIPictureDisp(New Icon(stream16))
                    End Using
                End If

                If resource32 IsNot Nothing Then
                    Using stream32 As Stream = assembly.GetManifestResourceStream(resource32)
                        largeIcon = IconToIPictureDisp(New Icon(stream32))
                    End Using
                End If

            Catch ex As Exception
                MessageBox.Show("Erro ao carregar ícones embutidos: " & ex.Message)
            End Try

            ' === CRIAÇÃO DO BOTÃO ===
            Try
                botaoSincronizarQTDE = DirectCast(controlDefs.Item("MyCompany_QTDEPERSONALIZADA"), ButtonDefinition)
            Catch
                botaoSincronizarQTDE = controlDefs.AddButtonDefinition(
                    "QTDE" & vbCrLf & "PERSONALIZADA",
                    "MyCompany_QTDEPERSONALIZADA",
                    CommandTypesEnum.kEditMaskCmdType,
                    Me.GetType().GUID.ToString("B"),
                    "Calcular quantidade total de peças e montagens",
                     "QTDE" & vbCrLf & "PERSONALIZADA",
                    smallIcon,
                    largeIcon)
            End Try

            AddHandler botaoSincronizarQTDE.OnExecute, AddressOf BotaoSincronizar_OnExecute

            ' === ADICIONA O BOTÃO À ABA TOOLS ===
            Dim ribbonAsm As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Assembly")
            Dim tabTools As RibbonTab = ribbonAsm.RibbonTabs("id_TabTools")

            Dim painel As RibbonPanel = Nothing
            Try
                painel = tabTools.RibbonPanels.Item("PainelItemNumbers")
            Catch
                painel = tabTools.RibbonPanels.Add("Item Numbers", "PainelItemNumbers", Me.GetType().GUID.ToString("B"))
            End Try

            Dim existe As Boolean = painel.CommandControls.OfType(Of CommandControl)().
                Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_SincronizarItemNumbers")

            If Not existe Then
                painel.CommandControls.AddButton(botaoSincronizarQTDE, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao ativar Add-In: " & ex.Message)
        End Try
    End Sub

    Private Sub BotaoSincronizar_OnExecute(ByVal Context As NameValueMap)
        Try
            _automacaoQTDE.Sincronizar()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar quantificação: " & ex.Message)
        End Try
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoQTDE = Nothing
    End Sub

    Public Sub ExecuteCommand(ByVal commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Método legado não utilizado
    End Sub

    ' === CONVERSÃO DE ÍCONE EMBUTIDO ===
    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub
        Public Shared Function ImageToPictureDisp(image As Drawing.Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class
End Class
